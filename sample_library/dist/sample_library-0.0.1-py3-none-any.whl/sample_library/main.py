import numpy as np

#Function that adds two arguments together without any error handling or helpful documentation that should be in place...
def add_from_library(a,b):
    return(a+b)

#Function that subtracts two arguments without any error handling or helpful documentation that should be in place...
def subtract_from_library(a,b):
    return(a-b)